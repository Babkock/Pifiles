# Sunset GTK Themes
Gtk2 themes base on [Adwaita](https://gitlab.gnome.org/GNOME/gnome-themes-extra/-/tree/gnome-3-22/themes) </br>
Gtk3 themes base on [Adwaita](https://gitlab.gnome.org/GNOME/gtk/-/tree/gtk-3-24/gtk/theme/Adwaita) </br>
Gnome shell themes base on [Adwaita](https://gitlab.gnome.org/GNOME/gtk/-/tree/gtk-3-24/gtk/theme/Adwaita) </br>
Xfwm4 themes base on [Default-theme](https://gitlab.xfce.org/Dridi/xfwm4/-/tree/master/themes/default)</br>
License : [GPLv3](https://choosealicense.com/licenses/gpl-3.0/)</br></br>
Theme can be download [here](https://www.pling.com/p/1336259/)</br></br>
SCREENSHOTS:</br>
![sunsetscreenshot](https://i.ibb.co/Z2rhPST/sunset-screenshots002.png "sunset screenshot")</br></br>
